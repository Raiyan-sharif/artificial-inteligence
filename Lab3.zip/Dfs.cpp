#include<bits/stdc++.h>
using namespace std;

int Nvertex, nedge, edge;
int visited[100], flag=0;
vector<int> adjV[100];
void dfs(int u, int Goal)
{
    visited[u] = 1;
    int m ;

    for(int i = 0 ; i < adjV[u].size() ; i++)
    {

        m = adjV[u][i];
        if(m==Goal){
            flag=1;
        }
        if(visited[m] == 0)
        {
            dfs(m, Goal);
        }
    }
    if(flag!=1)
        flag=0;

}


void createGraph(){
    for(int i=1;i<=Nvertex;i++){
        cout<<"Edge : ";
        cin>>nedge;
        for(int j=0;j<nedge;j++){
            cin>>edge;
            adjV[i].push_back(edge);
        }
    }

    for(int i=1;i<=Nvertex;i++){
        cout<<i<<"->";
        for(int j=0;j<adjV[i].size();j++){
            cout<<"->"<<adjV[i][j];
        }
        cout<<endl;
    }

}

int main()
{
    cout<<"Vertex: ";
    cin>>Nvertex;
    createGraph();
    int star, Goal;
    cout<<"Star: "<<endl;
    cin>>star;
    cout<<"Goal:"<<endl;
    cin>>Goal;
    dfs(star, Goal);
    if(flag==0)
        cout<<"Goal Not Found"<<endl;
    else
        cout<<"Goal Found"<<endl;
}
/*
7
3
2 3 5
2
4 6
1
7
0
1
6
1
5
0
*/

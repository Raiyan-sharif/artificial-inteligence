#include<iostream>
#include<cstdio>
using namespace std;

int main(){
    int v;
    scanf("%d",&v);
    int e;
    scanf("%d",&e);
    int graph[v][v]={0};
    for(int i=0;i<v;i++){
        for(int j=0;j<v;j++){
            graph[i][j]=0;
        }

    }
    for(int i=0;i<e;i++){
        int v1,v2;
        scanf("%d",&v1);
        scanf("%d",&v2);
        graph[v1-1][v2-1]=1;
    }
    for(int i=0;i<v;i++){
        for(int j=0;j<v;j++){
            printf("%d ",graph[i][j]);
        }
        printf("\n");
    }


}

/*
6
8
1 2
1 4
4 2
2 5
5 4
3 5
3 6
6 6
*/

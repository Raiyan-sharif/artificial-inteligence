#include<iostream>
#include<cstdio>
using namespace std;
int first=1;
int last=1;
int i=1;
int fibonacci(int cnt){
    if(cnt<=1){
        return cnt;
    }
    else{
        return fibonacci(cnt-1)+fibonacci(cnt-2);
    }

}
int main(){


    for(int i=1;i<25;i++){
    printf("%d ",fibonacci(i));
    }
}



#include<cstdio>
#include<iostream>
#include<cstring>
#include<string>
using namespace std;
string locationI,statusI;
string SimplereflexVacumAgent(string location, string status){
    if(status.compare("Dirty")==0){
        return "Suck";
    }
    else if(location.compare("A")==0){
        return "Right";
    }
    else if(location.compare("B")==0){
        return "Left";
    }

}
void interpretInput(){
    cin>>locationI;
    cin>>statusI;
    cout<<SimplereflexVacumAgent(locationI,statusI)<<endl;
}
int main(){
    interpretInput();
}

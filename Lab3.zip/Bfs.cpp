#include<bits/stdc++.h>
using namespace std;

int totalVertex, edgeNumber, edge;
int visited[100];
vector<int> adjV[100];

void Bfs(int sVertex, int Goal){
    int v;
    for(int i=0;i<=totalVertex;i++)
        visited[i]=0;
    queue<int> Q;
    Q.push(sVertex);
    visited[sVertex]=1;
    while(!Q.empty()){
        int u=Q.front();
        Q.pop();
        cout<<u<<"->";
        for(int i=0;i<adjV[u].size();i++){
            if(adjV[u][i]==Goal){
                cout<<"Goal Found"<<endl;
                return;
            }
            if(visited[adjV[u][i]]==0){
                v = adjV[u][i];
                visited[v]=1;
                Q.push(v);
            }
        }
    }
    cout<<"Goal not Found"<<endl;
}

void createGraph(){
    for(int i=1;i<=totalVertex;i++){
        cout<<"Vertex "<<i<<endl;
        cout<<"Edge : ";
        cin>>edgeNumber;
        for(int j=0;j<edgeNumber;j++){
            cin>>edge;
            adjV[i].push_back(edge);
        }
    }

    for(int i=1;i<=totalVertex;i++){
        cout<<i;
        for(int j=0;j<adjV[i].size();j++){
            cout<<"->"<<adjV[i][j];
        }
        cout<<endl;
    }

}

int main(){
    cout<<"Vertex: ";
    cin>>totalVertex;
    createGraph();
    int sVertex, Goal;
    cout<<"Start"<<endl;
    cin>>sVertex;
    cout<<"Goal Node"<<endl;
    cin>>Goal;
    Bfs(sVertex, Goal);
}

/*


7
3
2 3 5
2
4 6
1
7
0
1
6
1
5
0

*/
